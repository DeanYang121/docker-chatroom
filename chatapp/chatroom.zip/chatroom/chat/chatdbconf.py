#encoding: utf-8
MYSQL_HOST = 'mysql1'
MYSQL_PORT = 3306
MYSQL_USER = 'root'
MYSQL_PASSWD = '1234567'
MYSQL_DB = 'chatroom'
MYSQL_CHARSET = 'utf8mb4'
Unix_socket='/tmp/mysql.sock'